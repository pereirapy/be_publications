
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'pereirapy',
  applicationName: 'sweatworks-app',
  appUid: 'ZXPrHH8zncLfVLcKHB',
  orgUid: '512d35c4-ed21-4f30-bad8-ed1d8cfa6a00',
  deploymentUid: 'd931117f-b7d8-4b7d-aff5-87c3b0ad6cbe',
  serviceName: 'sweatworks',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '4.5.3',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'sweatworks-dev-getOneAuthor', timeout: 30 };

try {
  const userHandler = require('./handler.js');
  module.exports.handler = serverlessSDK.handler(userHandler.getOneAuthor, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}