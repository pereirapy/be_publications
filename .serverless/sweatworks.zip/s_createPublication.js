
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'pereirapy',
  applicationName: 'sweatworks-app',
  appUid: 'ZXPrHH8zncLfVLcKHB',
  orgUid: '512d35c4-ed21-4f30-bad8-ed1d8cfa6a00',
  deploymentUid: 'a113ed37-1b50-42e8-b7f7-5a227fa8225d',
  serviceName: 'sweatworks',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '4.5.3',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'sweatworks-dev-createPublication', timeout: 30 };

try {
  const userHandler = require('./handler.js');
  module.exports.handler = serverlessSDK.handler(userHandler.createPublication, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}