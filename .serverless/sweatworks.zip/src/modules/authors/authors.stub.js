const stubAuthors = [
  {
    id: 1,
    firstName: 'James',
    lastName: 'Joyce',
    email: 'james@hotmail.com',
    birtyDate: '1901-07-06'
  },
  {
    id: 2,
    firstName: 'Marcel',
    lastName: 'Proust',
    email: 'marcel@hotmail.com',
    birtyDate: '1900-07-11'
  }
]

export { stubAuthors }
