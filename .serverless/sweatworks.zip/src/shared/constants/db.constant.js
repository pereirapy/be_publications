const fieldsNoTypeText = ['createdAt', 'updatedAt']

module.exports = {
  fieldsNoTypeText
}
